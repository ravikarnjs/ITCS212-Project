To run our website:

[1] Extract the zip file named "sec1_gr10_pj1_ID120_179_181_210.zip".
[2] Open folder “sec1_gr10_src” in VScode.
*** NOT folder “sec1_gr10_pj1_ID120_170_181_210” in VScode.***
[3] Select html file named "HomePage.html" to starting run the code with live server and see the content in Home Page.
[4] Click the search icon in the navigation bar at the top of the page to search the content.
[5] Click the search icon in color brown[all of them can be clicked], it will be expanded the search bar.
[6] Click the detail button to see the details of each content in the Detail Page.
[7] Click the login icon to login or click Sign up to sign up.
[8] Click Forgot password to see what to do if you forget the password.
[9] Click the pencil button to login as an administrator, and Click the login button to be able manage the products and user accounts.
[10] Click the Admin ticketBoo icon to go back to the Home Page.
[11] Click the About button in the navigation bar at the top of the page to see the members in our group and all the references that we learnt from.

--------------------------------
File:
HomePage.html
aboutUs.html
AllDetails.html
Detail01.html
Detail02.html
Detail03.html
Detail04.html
Detail05.html
SearchPage.html
Signup.html
ForgotPass.html
Adminlogin.html
Product-management.html
Userlogin.html
User-account-management.html
product.html
---------------------------------


Start with "HomePage.html" 

<User Page>
Navigation: LOGO_______Home|About|Concert&Entertainment______Search|Favorite|ShoppingCart|Account
             -1-                     -2-                                    -3-

-1- Go to Home page (HomePage.html)

-2- 
	Home: Link to HomePage.html
	About: Link to aboutUs.html
	Concert&Entertainment: Link to AllDetails.html

-3-
	Search: Link to SearchPage.html
	Favorite: * No Content Here *
	ShoppingCart: * No Content Here *
	Account: Link to LoginPage.html


<Admin Page>
Navigation: LOGO_______Product Management|User Account Management______Account
             -1-                          -2-                            -3-

-1- Go to Home page (HomePage.html)

-2- 
	Product Management: Link to Product-management.html
	User Account Management: Link to User-account-management.html

-3-
	Account: Link to Adminlogin.html



<Every Page except Login Page, Forgot Pass Page, Sign-up Page>
Footer:	ticketBool!					          Hi!All of Concert Lovers				 Contact Us		
		- Home: Link to HomePage.html           * No Content Here *              * No Content Here *
		- About: Link to aboutUs.html
		- Detail: Link to AllDetails.html



Our Website is about "Booking Events"

How to use?
	1. Start with the HomePage.html
	   [HomePage.html]
		- we have slide bar showing the concert that link on that detail page.
		- we have recommend block showing the recommended concerts. You can see more detail by click ticket button
		  and you can click the heart on the right of the picture for set it as a favorite event and you can also dislike them.
		- You can click other page on footer section too.

	2. If you click "About" in navigation bar
	   [aboutUs.html]
		- This page shows the content of member in our group, and, below this part, all the content of references that we learnt from them will be shown.
		- Each references can be clinked to link to the source page.

	3. [AllDetails.html] (Ps. But the concert can click to see in detail only 5 events: 4 events in the top row and 1 event in the left 2nd row)
		- This page shows all the concert and entertainment in our website. And user can click to each concert
		  by clicking on the image or the button detail.
		3.1 "Detail01.html"
			- This page shows in details of the concert. And user will but the ticket in this page. This page will appear when the 
		 	 	user clinking on the previous page (AllDetails.html), and can connect to this page by clicking on the homepage by 
		  		clicking on the slide are shown and on the recommended.
		3.2 "Detail02.html"
			- This page shows in details of the concert. And user will but the ticket in this page. This page will appear when the 
		  		user clinking on the previous page (AllDetails.html), and can connect to this page by clicking on the homepage by 
		  		clicking on the slide are shown and on the recommended.
		3.3 "Detail03.html"
			- This page shows in details of the concert. And user will but the ticket in this page. This page will appear when the 
		  		user clinking on the previous page (AllDetails.html), and can connect to this page by clicking on the homepage by 
		  		clicking on the slide are shown and on the recommended.
		3.4 "Detail04.html"
			- This page shows in details of the concert. And user will but the ticket in this page. This page will appear when the 
		  		user clinking on the previous page (AllDetails.html), and can connect to this page by clicking on the homepage by 
		  		clicking on the slide are shown and on the recommended.
		3.5 "Detail05.html"
			- This page shows in details of the concert. And user will but the ticket in this page. This page will appear when the 
		  		user clinking on the previous page (AllDetails.html), and can connect to this page by clicking on the homepage by 
		  		clicking on the slide are shown and on the recommended.
		

	4. "Search" : the first icon at the right hand side
	   [SearchPage.html]
		- After clicked the search icon, it is linked to SearchPage.html.
		- SearchPage.html shows 3 search icon in brown color which are 3 criteria for searching.
		- The first search icon [beige color]: If this icon is clicked, it will be expanded and shown the text placeholder "search the name".
		- The second search icon [pink color]: If this icon is clicked, it will be expanded and shown the text placeholder "search the location".
		- The third search icon [light blue color]: If this icon is clicked, it will be expanded and shown the text placeholder "search the date".
		- The results will be displayed in this SearchPage.html if the white search icon at the right hand side of each search bar is clicked.
		- Each box of all the results show a picture which is a poster of a event, and the important details of the event will be shown below the poster.
		- And below the important detail of each boxes has the button named "detail". If the detail button is clicked, the page will be linked to the Detail[number of detail].html of each events.


	5. "Login page" : an people icon on the right hand side
	   [LoginPage.html]
		- This page shows Login form in the middle of the page.
		- In the form, it is required of Username and Password.
		- [1] Having an account: If the Login button is clicked, it will be linked to the [HomePage.html].
		- [2] Having an account but forgot the Password: It will be linked to ForgotPass.html which pop-up the form to reset the Password.
			  This form consists of Username, Email address, Password that is wanted to reset, and Comfirm that Password.
			  The form is required Email address. If submit button is clicked, it is linked to [LoginPage.html].
		- [3] Never have an account: Click the Sign up below the Login button, it is linked to [Signup.html] which pop-up the form to sign up.
			  This form is required Email address, Username, and Password. If submit button is clicked, it is linked to [LoginPage.html].

		[Adminlogin.html]
		- [1] Administrator login page : an pencil icon in the bottom of this page.
			  When click pencil icon, it will linked to [Adminlogin.html] page which pop-up the form of Username and Password.
			  If submit(login button), it is linked to Product/Service Management page[Product-management.html].

	6. Product/Service Management page[Product-management.html]:
		This page is linked with "admin navigation bar" and have 2 section.
		- [1] The first section is a "Add Product" button that linked to [Product.html].
			  [Product.html] is a page that you can enter information consist of Title, Description, Poster, Categories, Date, Time, and Price.
			  When you click Draft or Add will appear on the [Product-management.html] page. (But now cannot add it)
			  /*"Draft button" will appear with opacity 0.5 and the User cannot see draft But "Add button" will appear without opacity and User can see it*/
		- [2] The second section is all event that you add, it will appear in this section.

	7. User Account Management Page[User-account-management.html]:
		This page is linked with "admin navigation bar" and have 3 section.
		- [1] The first section is a form that you can insert a user by enter ID, Email, and Username and click insert.
			  When click it will pop-up at the below of this page.(Ps. But now still cannot add it)
		- [2] The second section is a search-box to find the ID of User or Administrator.
		- [3] The last section is a list of people who have an account in our page.

